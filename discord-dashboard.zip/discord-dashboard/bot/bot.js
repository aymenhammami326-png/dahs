const { Client, GatewayIntentBits, Events, ActivityType } = require('discord.js');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

// ============================================
// CONFIG - Replace with your values in .env
// ============================================
const BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_BOT_TOKEN_HERE';
const DASHBOARD_PORT = process.env.PORT || 3000;

// ============================================
// Discord Client Setup
// ============================================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildVoiceStates,
  ],
});

// ============================================
// Express + Socket.io Setup
// ============================================
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname + '/../frontend'));

// ============================================
// In-Memory Stats Store
// ============================================
let stats = {
  messageCount: 0,
  commandCount: 0,
  joinCount: 0,
  leaveCount: 0,
  startTime: Date.now(),
  recentEvents: [],
  guilds: [],
};

function addEvent(type, text, icon) {
  const event = {
    id: Date.now(),
    type,
    text,
    icon,
    time: new Date().toISOString(),
  };
  stats.recentEvents.unshift(event);
  if (stats.recentEvents.length > 50) stats.recentEvents.pop();
  io.emit('new_event', event);
  io.emit('stats_update', getPublicStats());
}

function getPublicStats() {
  const uptime = Math.floor((Date.now() - stats.startTime) / 1000);
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = uptime % 60;

  return {
    messageCount: stats.messageCount,
    commandCount: stats.commandCount,
    joinCount: stats.joinCount,
    leaveCount: stats.leaveCount,
    uptime: `${hours}h ${minutes}m ${seconds}s`,
    guildCount: client.guilds?.cache?.size || 0,
    memberCount: client.guilds?.cache?.reduce((a, g) => a + g.memberCount, 0) || 0,
    status: client.isReady() ? 'online' : 'offline',
    botTag: client.user?.tag || 'Unknown',
    botAvatar: client.user?.displayAvatarURL({ size: 128 }) || '',
    recentEvents: stats.recentEvents.slice(0, 20),
    guilds: client.guilds?.cache?.map(g => ({
      id: g.id,
      name: g.name,
      memberCount: g.memberCount,
      icon: g.iconURL({ size: 64 }) || null,
    })) || [],
  };
}

// ============================================
// REST API Routes
// ============================================
app.get('/api/stats', (req, res) => {
  res.json(getPublicStats());
});

app.post('/api/broadcast', async (req, res) => {
  const { guildId, channelId, message } = req.body;
  if (!guildId || !channelId || !message) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'Guild not found' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'Channel not found' });
    await channel.send(`📢 **Dashboard-Nachricht:** ${message}`);
    addEvent('broadcast', `Nachricht an #${channel.name} gesendet`, '📢');
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/guild/:guildId/channels', (req, res) => {
  const guild = client.guilds.cache.get(req.params.guildId);
  if (!guild) return res.status(404).json({ error: 'Guild not found' });
  const channels = guild.channels.cache
    .filter(c => c.type === 0) // Text channels only
    .map(c => ({ id: c.id, name: c.name }));
  res.json(channels);
});

// ============================================
// Discord Events
// ============================================
client.once(Events.ClientReady, (c) => {
  console.log(`✅ Bot bereit als ${c.user.tag}`);
  c.user.setActivity('das Dashboard 📊', { type: ActivityType.Watching });
  addEvent('ready', `Bot gestartet als ${c.user.tag}`, '🚀');
});

client.on(Events.MessageCreate, (message) => {
  if (message.author.bot) return;
  stats.messageCount++;

  // Simple commands
  if (message.content.startsWith('!')) {
    stats.commandCount++;
    const cmd = message.content.split(' ')[0].toLowerCase();

    if (cmd === '!ping') {
      message.reply(`🏓 Pong! Latenz: ${client.ws.ping}ms`);
      addEvent('command', `${message.author.tag} nutzte !ping`, '🏓');
    } else if (cmd === '!info') {
      message.reply(`📊 Ich bin auf ${client.guilds.cache.size} Servern mit ${getPublicStats().memberCount} Mitgliedern.`);
      addEvent('command', `${message.author.tag} nutzte !info`, '📊');
    } else if (cmd === '!uptime') {
      message.reply(`⏱️ Uptime: ${getPublicStats().uptime}`);
      addEvent('command', `${message.author.tag} nutzte !uptime`, '⏱️');
    } else if (cmd === '!help') {
      message.reply('📖 **Befehle:** `!ping` `!info` `!uptime` `!help`');
      addEvent('command', `${message.author.tag} nutzte !help`, '📖');
    } else {
      addEvent('command', `${message.author.tag} nutzte ${cmd}`, '⚡');
    }
  } else {
    addEvent('message', `Nachricht von ${message.author.tag} in #${message.channel.name}`, '💬');
  }
});

client.on(Events.GuildMemberAdd, (member) => {
  stats.joinCount++;
  addEvent('join', `${member.user.tag} ist beigetreten (${member.guild.name})`, '✅');
});

client.on(Events.GuildMemberRemove, (member) => {
  stats.leaveCount++;
  addEvent('leave', `${member.user.tag} hat verlassen (${member.guild.name})`, '👋');
});

client.on(Events.GuildCreate, (guild) => {
  addEvent('guild', `Bot zu ${guild.name} hinzugefügt (${guild.memberCount} Mitglieder)`, '🎉');
});

// ============================================
// Socket.io
// ============================================
io.on('connection', (socket) => {
  console.log('Dashboard verbunden:', socket.id);
  socket.emit('stats_update', getPublicStats());

  socket.on('disconnect', () => {
    console.log('Dashboard getrennt:', socket.id);
  });
});

// Update dashboard every 10 seconds
setInterval(() => {
  io.emit('stats_update', getPublicStats());
}, 10000);

// ============================================
// Start
// ============================================
server.listen(DASHBOARD_PORT, () => {
  console.log(`🌐 Dashboard läuft auf http://localhost:${DASHBOARD_PORT}`);
});

client.login(BOT_TOKEN).catch(err => {
  console.error('❌ Bot-Login fehlgeschlagen:', err.message);
});
