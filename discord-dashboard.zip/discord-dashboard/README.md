# ⚡ Discord Bot Dashboard

Ein vollständiges Discord-Bot-Dashboard mit Echtzeit-WebSocket-Updates.

## 📁 Projektstruktur

```
discord-dashboard/
├── bot/
│   └── bot.js          ← Discord Bot + Express API + Socket.io
├── frontend/
│   └── index.html      ← Das Web-Dashboard
├── package.json
├── .env.example
└── README.md
```

## 🚀 Setup

### 1. Abhängigkeiten installieren

```bash
npm install
```

### 2. Bot-Token einrichten

```bash
cp .env.example .env
```

Trage deinen Bot-Token in `.env` ein:

```
BOT_TOKEN=dein_token_hier
PORT=3000
```

### 3. Discord Bot erstellen (falls noch nicht vorhanden)

1. Gehe zu https://discord.com/developers/applications
2. Klicke "New Application"
3. Gehe zu "Bot" → "Add Bot"
4. Kopiere den Token → in `.env` eintragen
5. Aktiviere folgende **Privileged Gateway Intents**:
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT
   - ✅ PRESENCE INTENT

6. Bot einladen (unter OAuth2 → URL Generator):
   - Scopes: `bot`
   - Permissions: `Send Messages`, `Read Messages`, `View Channels`

### 4. Starten

```bash
npm start
# oder für Development:
npm run dev
```

### 5. Dashboard öffnen

```
http://localhost:3000
```

---

## 📊 Dashboard-Features

| Feature | Beschreibung |
|---|---|
| **Übersicht** | Bot-Status, Statistiken, Live-Events, Server-Liste |
| **Live-Events** | Echtzeit-Feed aller Bot-Ereignisse via WebSocket |
| **Server** | Alle Server auf denen der Bot ist |
| **Broadcast** | Nachrichten direkt aus dem Dashboard senden |
| **Befehle** | Liste aller Bot-Befehle |

## 🤖 Bot-Befehle

| Befehl | Beschreibung |
|---|---|
| `!ping` | Zeigt die Bot-Latenz |
| `!info` | Server & Mitgliederzahl |
| `!uptime` | Bot-Laufzeit |
| `!help` | Alle Befehle |

## 🔌 API-Endpoints

| Route | Methode | Beschreibung |
|---|---|---|
| `/api/stats` | GET | Bot-Statistiken |
| `/api/broadcast` | POST | Nachricht senden |
| `/api/guild/:id/channels` | GET | Channels eines Servers |

## 🛠️ Erweiterungsideen

- Slash Commands hinzufügen
- Moderations-Log
- Willkommensnachrichten konfigurieren
- Auto-Rollen
- Musik-Player-Controls
